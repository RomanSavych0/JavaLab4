package BuisnessLogic.Interfaces;

import Data.Car;

import java.util.ArrayList;
import java.util.List;

public interface ILogic {

    int getPassengerNumber(ArrayList<Car>cars);
    int getBaggageCount(ArrayList<Car>cars);
    void sortByComfortLevel(ArrayList<Car>cars);
    List<Car> getCarByPassengerNumber(List<Car>cars , int min , int max);


}
