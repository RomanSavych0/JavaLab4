package Data.CarClases;

import Data.CarClases.Car;

public class CarMediumLevel extends Car {
    public CarMediumLevel(int passengerNumber, double baggageNumber) {
        super(passengerNumber, baggageNumber);
        this.comfortLevel = 70;

    }


}
