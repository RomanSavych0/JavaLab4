package Data;

import java.util.Comparator;
import java.util.Objects;

public class Car implements Comparable<Car>{
 private    int passengerNumber;
    private  double baggageNumber;
    private int comfortLevel;

    public int getComfortLevel() {
        return comfortLevel;
    }




    public double getBaggageNumber() {
        return baggageNumber;
    }


    public int getPassengerNumber() {
        return passengerNumber;
    }




    @Override
    public int compareTo(Car o) {
        return this.comfortLevel - o.getComfortLevel();
    }
}
