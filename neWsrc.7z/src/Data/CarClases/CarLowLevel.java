package Data.CarClases;

import Data.CarClases.Car;

public class CarLowLevel extends Car {

    public CarLowLevel(int passengerNumber, double baggageNumber) {
        super(passengerNumber, baggageNumber);
        this.comfortLevel = 10;

    }


}
