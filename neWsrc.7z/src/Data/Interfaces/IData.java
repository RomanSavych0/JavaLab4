package Data.Interfaces;

import Data.CarClases.Car;

import java.util.List;

public interface IData {
    List<Car>getAllCars();


}
